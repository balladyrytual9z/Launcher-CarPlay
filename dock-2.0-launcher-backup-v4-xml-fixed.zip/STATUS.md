# Dock 2.0 CarPlay Launcher - backup status
Data: 2026-10-31, v4 (naprawione wiodace puste linie w XML: deklaracja <?xml?> musi byc w linii 1).

Wszystkie poprawki z instrukcji ZAKOŃCZONE. versionCode 4, versionName 1.0.5-dock2-circadian-sun.
POZOSTAŁO: build przez workflow w repo (zip w repo lub push plikow) → Release z APK.
