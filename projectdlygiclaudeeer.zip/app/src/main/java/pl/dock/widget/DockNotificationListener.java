package pl.dock.widget;

import android.app.Notification;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;

// Daje dostęp do sesji multimedialnych innych aplikacji (np. DiPlay) i ich powiadomień.
// Wymaga jednorazowego włączenia "Dostępu do powiadomień" dla Docka w ustawieniach Androida.
public class DockNotificationListener extends NotificationListenerService {

    private static volatile DockNotificationListener instance;
    private static volatile String removedKey = "";

    public static boolean connected() {
        return instance != null;
    }

    public static boolean hasNotificationFrom(String pkg) {
        return notificationText(pkg) != null;
    }

    // tytuł i tekst pierwszego aktywnego powiadomienia aplikacji (null = brak)
    public static String[] notificationText(String pkg) {
        DockNotificationListener l = instance;
        if (l == null || pkg == null) return null;
        try {
            StatusBarNotification[] all = l.getActiveNotifications();
            if (all == null) return null;
            for (StatusBarNotification n : all) {
                if (!pkg.equals(n.getPackageName())) continue;
                if (n.getKey() != null && n.getKey().equals(removedKey)) continue;
                android.os.Bundle ex = n.getNotification().extras;
                CharSequence t = ex == null ? null : ex.getCharSequence(Notification.EXTRA_TITLE);
                CharSequence x = ex == null ? null : ex.getCharSequence(Notification.EXTRA_TEXT);
                return new String[]{t == null ? "" : t.toString(), x == null ? "" : x.toString()};
            }
        } catch (Throwable ignored) {
        }
        return null;
    }

    @Override
    public void onListenerConnected() {
        instance = this;
        removedKey = "";
        MediaHub.get().onListenerEvent();
        notifyStatus();
    }

    @Override
    public void onListenerDisconnected() {
        instance = null;
    }

    @Override
    public void onNotificationPosted(StatusBarNotification sbn) {
        if (sbn != null && sbn.getKey() != null && sbn.getKey().equals(removedKey)) removedKey = "";
        MediaHub.get().onListenerEvent();
        notifyStatus();
    }

    @Override
    public void onNotificationRemoved(StatusBarNotification sbn) {
        // w chwili zdarzenia lista aktywnych może jeszcze zawierać usuwane powiadomienie
        removedKey = sbn == null || sbn.getKey() == null ? "" : sbn.getKey();
        MediaHub.get().onListenerEvent();
        notifyStatus();
    }

    // zmiana stanu CarPlay jest zgłaszana od razu, bez czekania na okresowe odświeżenie
    private void notifyStatus() {
        try {
            StatusCenter.refreshCp(this);
            DockWidget.updateAll(this);
        } catch (Throwable ignored) {
        }
    }
}
