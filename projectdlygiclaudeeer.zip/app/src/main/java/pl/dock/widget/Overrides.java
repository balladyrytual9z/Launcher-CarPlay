package pl.dock.widget;

import java.util.Locale;

// Stałe nazwy i ikony niektórych aplikacji w launcherze (dopasowanie po nazwie widocznej na liście)
public class Overrides {

    public static class O {
        public final String label;
        public final String icon;

        O(String label, String icon) {
            this.label = label;
            this.icon = icon;
        }
    }

    public static O match(String label) {
        if (label == null) return null;
        String l = label.trim().toLowerCase(Locale.US);
        if (l.equals("diplay")) return new O("CarPlay", "carplay");
        if (l.equals("localsend")) return new O("AirDrop", "airdrop");
        if (l.contains("f-droid") || l.equals("fdroid")) return new O(label, "appstore");
        if ("obd".equals(BuiltinIcons.suggest(label))) return new O(label, "obdgear");
        return null;
    }
}
