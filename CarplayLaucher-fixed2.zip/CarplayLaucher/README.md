# Dock (CarPlay Launcher)

Android launcher/widget for tablet (API 26+, target 28).

## CI (GitHub Actions)

Workflow builds a **debug** APK with:

- Java 17
- Gradle 8.9
- Android SDK platform 35 / build-tools 35.0.0
- AGP 8.5.2

```bash
gradle --no-daemon clean assembleDebug
```

Output: `app/build/outputs/apk/debug/app-debug.apk`

Debug signing uses `app/dock-debug.p12` (alias `dock`, password `dockdock`).

## Project layout

```
CarplayLaucher/
  settings.gradle
  build.gradle
  gradle.properties
  app/
    build.gradle
    dock-debug.p12
    src/main/...
```
