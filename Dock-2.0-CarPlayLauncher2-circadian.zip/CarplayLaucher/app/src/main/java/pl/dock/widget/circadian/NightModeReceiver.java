package pl.dock.widget.circadian;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import pl.dock.widget.Prefs;

public class NightModeReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context c, Intent i) {
        if (!"pl.dock.widget.NIGHT_MODE_CHANGED".equals(i.getAction())) return;
        boolean isNight = i.getBooleanExtra("isNight", false);
        if (isNight && Prefs.circadianAuto(c) && CircadianBridge.isInstalled(c)) {
            CircadianBridge.activateForNight(c);
        }
    }
}
