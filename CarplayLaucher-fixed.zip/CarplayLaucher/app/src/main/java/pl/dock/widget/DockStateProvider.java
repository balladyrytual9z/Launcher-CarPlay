package pl.dock.widget;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.os.Process;

import org.json.JSONArray;

import java.util.List;

/** ContentProvider do komunikacji z innymi aplikacjami (stan stron, wybrane pakiety). */
public class DockStateProvider extends ContentProvider {

    public static final String AUTHORITY = "pl.dock.widget.state";

    @Override
    public boolean onCreate() {
        return true;
    }

    @Override
    public Bundle call(String method, String arg, Bundle extras) {
        if (getContext() == null) return null;
        String caller = callerPackage();
        Bundle b = new Bundle();
        if ("get_state".equals(method)) {
            LauncherActivity la = LauncherActivity.current();
            b.putString("last_page", Prefs.lastPage(getContext()));
            b.putString("external_caller", Prefs.externalCaller(getContext()));
            if (la != null) {
                la.fillStateBundle(b);
            } else {
                b.putString("page", Prefs.lastPage(getContext()));
                b.putInt("page_index", -1);
                b.putInt("home_index", -1);
                b.putInt("apps_index", -1);
                b.putInt("pages_total", 0);
            }
            return b;
        }
        if ("get_selected".equals(method)) {
            List<String> sel = Prefs.selectedPkgs(getContext());
            JSONArray a = new JSONArray();
            for (String s : sel) a.put(s);
            b.putString("pkgs", a.toString());
            return b;
        }
        if ("navigate".equals(method)) {
            if (!trusted(caller)) return denied();
            LauncherActivity la = LauncherActivity.current();
            if (la == null) {
                if (arg != null) Prefs.setLastPage(getContext(), arg);
                return ok("saved");
            }
            if (arg != null) {
                Prefs.setExternalCaller(getContext(), caller == null ? "" : caller);
                la.navigateToPage(arg);
            }
            return ok("navigated");
        }
        if ("set_page".equals(method)) {
            if (!trusted(caller)) return denied();
            String page = extras == null ? null : extras.getString("page");
            if (page != null) Prefs.setLastPage(getContext(), page);
            return ok("saved");
        }
        return null;
    }

    private boolean trusted(String caller) {
        if (caller == null) return false;
        return Prefs.trustedCallers(getContext()).contains(caller);
    }

    private Bundle denied() {
        Bundle b = new Bundle();
        b.putBoolean("ok", false);
        b.putString("reason", "caller not trusted");
        return b;
    }

    private Bundle ok(String what) {
        Bundle b = new Bundle();
        b.putBoolean("ok", true);
        b.putString("result", what);
        return b;
    }

    private String callerPackage() {
        try {
            int uid = android.os.Binder.getCallingUid();
            if (uid == Process.myUid()) return getContext().getPackageName();
            String[] pkgs = getContext().getPackageManager().getPackagesForUid(uid);
            return (pkgs != null && pkgs.length > 0) ? pkgs[0] : null;
        } catch (Throwable t) {
            return null;
        }
    }

    @Override
    public Cursor query(Uri u, String[] p, String s, String[] a, String o) {
        return null;
    }

    @Override
    public String getType(Uri u) {
        return null;
    }

    @Override
    public Uri insert(Uri u, ContentValues v) {
        return null;
    }

    @Override
    public int delete(Uri u, String s, String[] a) {
        return 0;
    }

    @Override
    public int update(Uri u, ContentValues v, String s, String[] a) {
        return 0;
    }
}
